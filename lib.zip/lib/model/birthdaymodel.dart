class BirthdayModel{
  String name;
  String date;
  BirthdayModel(this.name,this.date);
}