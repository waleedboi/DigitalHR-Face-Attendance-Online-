class DepartmentModel{
  int id;
  String departmentname;
  DepartmentModel(this.id,this.departmentname);
}
