// class ShiftModel{
//   int id;
//   String title;
//   ShiftModel(this.id,this.title);
// }