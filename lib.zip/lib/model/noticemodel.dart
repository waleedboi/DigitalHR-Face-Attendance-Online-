class NoticeModel{
  String title;
  String description;
  String dateTime;
  NoticeModel(this.title,this.description,this.dateTime);
}