class  HolidayModel{
  String title;
  DateTime dateTime;
  HolidayModel(this.title,this.dateTime);
}