import 'dart:ui';

const appIcon = 'assets/icons/app_icon.png';
// const appIcon = 'assets/images/attendance.png';
// const splashIcon = 'assets/icons/app_icon.png';
const backgroundImage = 'assets/images/back.png';
const dummyprofile = 'assets/images/dummyptofileImage.png';
const checkInImage = 'assets/images/checkin.png';
const breakActive = 'assets/images/break_active.png';
const breakInactive = 'assets/images/break_inactive.png';

const isDemo = true;

//color
var appThemeColor = const Color(0xFF011754);
var appAlternateColor = const Color(0xFF041033);
